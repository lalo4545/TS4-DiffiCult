# The Great Reckoning

Every 10 weeks hold a ritual and summon all the ghosts

**DO NOT START A RECKONING COUNT UNTIL YOU HAVE AT LEAST 1 GHOST ON YOUR LOT**

Spin The Great Reckoning Wheel and see if you get a:

- Reunion
    - Have a family get-together
    - Invite as many members as you can, use your groups if needed.
    - Cheat Need for everyone and work on relationships / have a good time
- Uprising
    - Spin a Tier 1 penance
    - Spin a Tier 2 penance
    - Start a fight with the person who has the lowest relationship with you.
        - If you end the week with max dislike for that person you have  to kill them
- Peace
    - One of the ghosts transcends, either through rebirth or moving on -2 SP
    - Cheat a focused or happy potion

[Return](https://www.notion.so/TS4-Diffy-Cult-Challenge-28ceed3eb83180f5b0f0f4e031163a32?pvs=21)