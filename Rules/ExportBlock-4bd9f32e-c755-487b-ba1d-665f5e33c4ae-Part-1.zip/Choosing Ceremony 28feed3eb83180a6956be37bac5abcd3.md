# Choosing Ceremony

---

When your **heir becomes an Elder** 

1. **Throw a party** and invite all eligible Acting Leaders to attend
2. Either
    1. Have an elimination event where the last one is chosen
    2. Spin the Pop-corn household  wheel and choose among the available there
3. Move [Chosen Household](Chosen%20Household%2028feed3eb831805cbff3dbc18d19f9d2.md) in
    1. Only the Acting Leader and your Heir must remain on the Cult Lot