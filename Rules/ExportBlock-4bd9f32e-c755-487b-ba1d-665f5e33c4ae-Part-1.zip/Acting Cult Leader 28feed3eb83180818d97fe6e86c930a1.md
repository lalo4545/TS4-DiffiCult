# Acting Cult Leader

---

> Chosen leader by heir
> 
- Must be a member of the [Chosen Household](Chosen%20Household%2028feed3eb831805cbff3dbc18d19f9d2.md)
- Must be a **teen or above**
- Must be at least a **follower** level
- Must uphold all Leadership duties in place of the heir

🚫 If no sims match this category at your heir’s death then you have failed the challenge

---

✅ You can adopt members of your own bloodline into your Chosen Household

✅ You can have science babies

✅ You can adopt children, toddlers, and infants

---

**Return** to [Rules](Rules%20Lore%2028deed3eb83180b1965afd46279ad482.md)

**Return** to [Dashboard](https://www.notion.so/TS4-Diffy-Cult-Challenge-28ceed3eb83180f5b0f0f4e031163a32?pvs=21)