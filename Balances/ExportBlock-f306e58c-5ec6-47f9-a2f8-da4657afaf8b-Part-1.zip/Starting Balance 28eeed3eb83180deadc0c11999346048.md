# Starting Balance

Amount: -100000
Balance Calculator: Untitled (https://www.notion.so/28eeed3eb8318019ac80fdcbe1176e0f?pvs=21)
ID: 1